$(document).ready(function(){
  $('.sidenav').sidenav();
});
$('.carousel.carousel-slider').carousel({
  fullWidth: true,
});